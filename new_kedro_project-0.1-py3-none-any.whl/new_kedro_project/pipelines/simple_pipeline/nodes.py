
# Prepare first node
def return_greeting():

    return "Hello"